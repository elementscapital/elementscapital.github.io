A Pen created at CodePen.io. You can find this one at https://codepen.io/flmbray/pen/ByYxQo.

 Construct a 17-gon (a "Heptadecagon" I'm told) using techniques that require only compass and straightedge (circles, arcs, midpoints).